package game;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;

import java.io.Serializable;

public abstract class GameObjects implements Serializable {
    public GameObjects() {
    }
}
