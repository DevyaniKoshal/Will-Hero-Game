package game;

public class ChestPos {
    private int code;
    private int x;
    private int y;


    public ChestPos(int codeNo, int xc, int yc){
        this.code = codeNo;
        this.x = xc;
        this.y = yc;
    }
}
